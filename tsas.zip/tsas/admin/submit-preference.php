<?php
session_start();
include('includes/dbconnection.php');

// Check if the form is submitted
if (isset($_POST['submit_preference'])) {
    // Collect data from the form
    $teacherName = $_POST['teacher_name'];
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $note = $_POST['note'];

    // You will need to have a way to retrieve TeacherID based on TeacherName
    // Here we assume you have a session or another method to get TeacherID
    $teacherID = $_SESSION['tsasaid']; // Assuming teacher ID is stored in session

    // Insert the preference into the database
    $sql = "INSERT INTO tblteacherpreferences (TeacherID, TeacherName, Subject, PreferenceDate, PreferenceTime, Note) 
            VALUES (:teacherID, :teacherName, :subject, :date, :time, :note)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':teacherID', $teacherID, PDO::PARAM_INT);
    $query->bindParam(':teacherName', $teacherName, PDO::PARAM_STR);
    $query->bindParam(':subject', $subject, PDO::PARAM_STR);
    $query->bindParam(':date', $date, PDO::PARAM_STR);
    $query->bindParam(':time', $time, PDO::PARAM_STR);
    $query->bindParam(':note', $note, PDO::PARAM_STR);

    if ($query->execute()) {
        echo "<script>alert('Preference submitted successfully'); window.location.href='teacher-preference.php';</script>";
    } else {
        echo "<script>alert('Error submitting preference'); window.location.href='teacher-preference.php';</script>";
    }
}
?>
