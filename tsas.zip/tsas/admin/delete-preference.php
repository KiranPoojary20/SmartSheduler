<?php
session_start();
include('includes/dbconnection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM tblteacherpreferences WHERE ID=:id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_INT);
    $query->execute();
    header('Location: admin-preferences.php');
}
?>
