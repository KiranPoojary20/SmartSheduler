<?php
include('includes/dbconnection.php');

if (isset($_POST['semester'])) {
    $semester = $_POST['semester'];

    // Fetch subjects based on semester from the database
    $sql = "SELECT Subject FROM tblsubjects WHERE Semester=:semester";
    $query = $dbh->prepare($sql);
    $query->bindParam(':semester', $semester, PDO::PARAM_STR);
    $query->execute();
    $subjects = $query->fetchAll(PDO::FETCH_ASSOC);

    // Return the subjects as options for the dropdown
    foreach ($subjects as $subject) {
        echo '<option value="'.$subject['Subject'].'">'.$subject['Subject'].'</option>';
    }
}
?>
