<!DOCTYPE html>
<html lang="en">
<head>
    <title>Faculty Preferences</title>
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Add Faculty Preference</h2>
        <form method="post" action="submit-preference.php"> <!-- Updated action to submit-preference.php -->
            <div class="form-group">
                <label>Faculty Name</label>
                <input type="text" class="form-control" name="teacher_name" placeholder="Enter your name" required>
            </div>

            <!-- Dropdown for Semester -->
            <div class="form-group">
                <label>Semester</label>
                <select id="semester" class="form-control" name="semester" required>
                    <option value="">Select Semester</option>
                    <option value="sem1">Semester 1</option>
                    <option value="sem2">Semester 2</option>
                    <option value="sem3">Semester 3</option>
                    <option value="sem4">Semester 4</option>
                </select>
            </div>

            <!-- Dropdown for Subject, loaded dynamically -->
            <div class="form-group">
                <label>Subject</label>
                <select id="subject" class="form-control" name="subject" required>
                    <option value="">Select Subject</option>
                    <!-- Options will be loaded dynamically -->
                </select>
            </div>

            <div class="form-group">
                <label>Date</label>
                <input type="date" class="form-control" name="date" required>
            </div>
            <div class="form-group">
                <label>Time</label>
                <input type="time" class="form-control" name="time" required>
            </div>
            <div class="form-group">
                <label>Note</label>
                <textarea class="form-control" name="note" required></textarea>
            </div>
            <button type="submit" name="submit_preference" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <script>
        $(document).ready(function() {
            // Load subjects based on selected semester
            $('#semester').change(function() {
                var semester = $(this).val();

                // AJAX call to fetch subjects from the database
                $.ajax({
                    url: 'fetch-subjects.php',
                    method: 'POST',
                    data: {semester: semester},
                    success: function(data) {
                        $('#subject').html(data);
                    }
                });
            });
        });
    </script>
</body>
</html>
