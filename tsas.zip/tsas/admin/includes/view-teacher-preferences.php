<?php 
session_start();
include('includes/dbconnection.php');

// Fetch teacher preferences to display
$sql = "SELECT * FROM tblteacherpreferences";
$query = $dbh->prepare($sql);
$query->execute();
$preferences = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Teacher Preferences</title>
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Teacher Preferences</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Faculty Name</th>
                    <th>Subject</th>
                    <th>Preference Date</th>
                    <th>Preference Time</th>
                    <th>Note</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($preferences) {
                    foreach ($preferences as $preference) {
                        echo "<tr>
                                <td>{$preference['ID']}</td>
                                <td>{$preference['TeacherName']}</td>
                                <td>{$preference['Subject']}</td>
                                <td>{$preference['PreferenceDate']}</td>
                                <td>{$preference['PreferenceTime']}</td>
                                <td>{$preference['Note']}</td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No preferences found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
