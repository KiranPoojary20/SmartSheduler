<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// Check if the user is already logged in
if (isset($_SESSION['tsasaid'])) {
    header('location:teacher-preference.php'); // Redirect to the teacher preference page
}

if (isset($_POST['login'])) {
    // Capture form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate that both fields are filled
    if (!empty($username) && !empty($password)) {
        // Prepare SQL query to check username and password
        $sql = "SELECT * FROM tblteachers WHERE Username = :username AND Password = :password"; // Ensure passwords are hashed
        $query = $dbh->prepare($sql);
        $query->bindParam(':username', $username, PDO::PARAM_STR);
        $query->bindParam(':password', $password, PDO::PARAM_STR); // Ideally, use password_hash and password_verify
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // Set session variable
            $_SESSION['tsasaid'] = $result['ID']; // Assuming ID is the primary key in the tblteachers
            header('location:teacher-preference.php'); // Redirect to the teacher preference page
        } else {
            echo "<script>alert('Invalid username or password.');</script>";
        }
    } else {
        echo "<script>alert('Please fill in all fields.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Teacher Login</title>
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Teacher Login</h2>
        <form method="post" action="">
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" name="username" placeholder="Enter your username" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary">Login</button>
        </form>
    </div>
</body>
</html>
