<?php 
session_start();
include('includes/dbconnection.php');

// Handle form submission for adding subjects
if (isset($_POST['add_subject'])) {
    $semester = $_POST['semester'];
    $subject = $_POST['subject'];

    $sql = "INSERT INTO tblsubjects (Semester, Subject) VALUES (:semester, :subject)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':semester', $semester, PDO::PARAM_STR);
    $query->bindParam(':subject', $subject, PDO::PARAM_STR);
    $query->execute();
}

// Handle subject deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    $sql = "DELETE FROM tblsubjects WHERE ID=:delete_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_id', $delete_id, PDO::PARAM_INT);
    $query->execute();
    echo "<script>alert('Subject deleted successfully');</script>";
    header('Location: admin-preferences.php'); // Redirect to refresh the page
}

// Handle preference deletion
if (isset($_GET['delete_preference_id'])) {
    $delete_preference_id = $_GET['delete_preference_id'];

    $sql = "DELETE FROM tblteacherpreferences WHERE ID=:delete_preference_id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':delete_preference_id', $delete_preference_id, PDO::PARAM_INT);
    $query->execute();
    echo "<script>alert('Teacher preference deleted successfully');</script>";
    header('Location: admin-preferences.php'); // Redirect to refresh the page
}

// Fetch all subjects for display
$sql = "SELECT * FROM tblsubjects";
$query = $dbh->prepare($sql);
$query->execute();
$subjects = $query->fetchAll(PDO::FETCH_ASSOC);

// Fetch teacher preferences to display
$sql = "SELECT * FROM tblteacherpreferences";
$query = $dbh->prepare($sql);
$query->execute();
$preferences = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Preferences</title>
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Add Subject</h2>
        <form method="post" action="">
            <div class="form-group">
                <label>Semester</label>
                <select class="form-control" name="semester" required>
                    <option value="">Select Semester</option>
                    <option value="sem1">Semester 1</option>
                    <option value="sem2">Semester 2</option>
                    <option value="sem3">Semester 3</option>
                    <option value="sem4">Semester 4</option>
                </select>
            </div>
            <div class="form-group">
                <label>Subject</label>
                <input type="text" class="form-control" name="subject" required>
            </div>
            <button type="submit" name="add_subject" class="btn btn-primary">Add Subject</button>
        </form>

        <h2>Existing Subjects</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Semester</th>
                    <th>Subject</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subjects as $sub): ?>
                    <tr>
                        <td><?= $sub['ID'] ?></td>
                        <td><?= $sub['Semester'] ?></td>
                        <td><?= $sub['Subject'] ?></td>
                        <td>
                            <a href="?delete_id=<?= $sub['ID'] ?>" class="btn btn-danger btn-sm" 
                               onclick="return confirm('Are you sure you want to delete this subject?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Display Teacher Preferences -->
        <h2>Faculty Preferences</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Faculty Name</th>
                    <th>Subject</th>
                    <th>Preference Date</th>
                    <th>Preference Time</th>
                    <th>Note</th>
                    <th>Action</th> <!-- Added Action column -->
                </tr>
            </thead>
            <tbody>
                <?php if ($preferences): ?>
                    <?php foreach ($preferences as $preference): ?>
                        <tr>
                            <td><?= $preference['ID'] ?></td>
                            <td><?= $preference['TeacherName'] ?></td>
                            <td><?= $preference['Subject'] ?></td>
                            <td><?= $preference['PreferenceDate'] ?></td>
                            <td><?= $preference['PreferenceTime'] ?></td>
                            <td><?= $preference['Note'] ?></td>
                            <td>
                                <a href="?delete_preference_id=<?= $preference['ID'] ?>" class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Are you sure you want to delete this preference?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="7" class="text-center">No preferences found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
